package hotelmanagementsystem;

import java.awt.Color;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;

public class Reception extends JFrame implements ActionListener{
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12;

    Reception(){
        b1 = new JButton("New Customer Form");
        b1.setBounds(20,20,200,30);
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.BLACK);
        b1.addActionListener(this);
        add(b1);
        
        b2 = new JButton("Room");
        b2.setBounds(20,60,200,30);
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.BLACK);
        b2.addActionListener(this);
        add(b2);
        
        b3 = new JButton("Department");
        b3.setBounds(20,100,200,30);
        b3.setForeground(Color.WHITE);
        b3.setBackground(Color.BLACK);
        b3.addActionListener(this);
        add(b3);
        
        b4 = new JButton("All Employee Info");
        b4.setBounds(20,140,200,30);
        b4.setForeground(Color.WHITE);
        b4.setBackground(Color.BLACK);
        b4.addActionListener(this);
        add(b4);
        
        b5 = new JButton("Customer Info");
        b5.setBounds(20,180,200,30);
        b5.setForeground(Color.WHITE);
        b5.setBackground(Color.BLACK);
        b5.addActionListener(this);
        add(b5);
        
        b6 = new JButton("Manager Info");
        b6.setBounds(20,220,200,30);
        b6.setForeground(Color.WHITE);
        b6.setBackground(Color.BLACK);
        b6.addActionListener(this);
        add(b6);
        
        b7 = new JButton("Check Out");
        b7.setBounds(20,260,200,30);
        b7.setForeground(Color.WHITE);
        b7.setBackground(Color.BLACK);
        b7.addActionListener(this);
        add(b7);
        
        b8 = new JButton("Update Checkout Status");
        b8.setBounds(20,300,200,30);
        b8.setForeground(Color.WHITE);
        b8.setBackground(Color.BLACK);
        b8.addActionListener(this);
        add(b8);
        
        b9 = new JButton("Update Room Status");
        b9.setBounds(20,340,200,30);
        b9.setForeground(Color.WHITE);
        b9.setBackground(Color.BLACK);
        b9.addActionListener(this);
        add(b9);
        
        b10 = new JButton(" Pickup Service");
        b10.setBounds(20,380,200,30);
        b10.setForeground(Color.WHITE);
        b10.setBackground(Color.BLACK);
        b10.addActionListener(this);
        add(b10);
        
        b11 = new JButton("Search Room");
        b11.setBounds(20,420,200,30);
        b11.setForeground(Color.WHITE);
        b11.setBackground(Color.BLACK);
        b11.addActionListener(this);
        add(b11);
        
        b12 = new JButton("Log Out");
        b12.setBounds(20,460,200,30);
        b12.setForeground(Color.WHITE);
        b12.setBackground(Color.BLACK);
        b12.addActionListener(this);
        add(b12);
        
        JLabel title = new JLabel("RECEPTION");
        title.setBounds(410,20,200,30);
        title.setForeground(Color.BLACK);
        title.setFont(new Font("Tahoma", Font.BOLD, 30));
        add(title);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotelmanagementsystem/icons/reception.png"));
        Image i2 = i1.getImage().getScaledInstance(510,370,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l2 = new JLabel(i3);
        l2.setBounds(250,80,510,370);
        add(l2);
        
        getContentPane().setBackground(Color.WHITE);
        
        setLayout(null);
        setBounds(230,100,800,550);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            new AddCustomer().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource() == b2){
            new Room().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource() == b3){
        	try {
				new Department().setVisible(true);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            this.setVisible(false);
        }else if(ae.getSource() == b4){
            new EmployeeInfo().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource() == b5){
            new CustomerInfo().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource() == b6){
            new ManagerInfo().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource() == b7){
            new CheckOut().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource() == b8){
            new UpdateCheck().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource() == b9){
            new UpdateRoom().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource() == b10){
        	try {
				new PickUp().setVisible(true);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            this.setVisible(false);
        }else if(ae.getSource() == b11){
            try {
				new SearchRoom().setVisible(true);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            this.setVisible(false);
        }else if(ae.getSource() == b12){
            this.setVisible(false);
        }
    }
 public static void main(String[] args) {
        new Reception();   
}
}