package hotelmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddRooms extends JFrame implements ActionListener{
    JTextField t1,t2;
    JComboBox c1,c2,c3;
    JButton b1,b2;
    
    AddRooms(){
        
        JLabel l1 = new JLabel("ADD ROOMS");
        l1.setBounds(140,20,150,20);
        l1.setForeground(Color.BLACK);
        l1.setFont(new Font("Tahoma", Font.BOLD, 18));
        add(l1);
        
        JLabel room = new JLabel("Room Number");
        room.setFont(new Font("Tahoma", Font.PLAIN, 17));
        room.setBounds(40,60,130,20);
        add(room);
        
        t1 = new JTextField();
        t1.setBounds(200,60,150,30);
        add(t1);
        
        JLabel available = new JLabel("Available");
        available.setFont(new Font("Tahoma", Font.PLAIN, 17));
        available.setBounds(40,100,130,20);
        add(available);
        
        String str[] = {"Available","Occupied"};
        c1 = new JComboBox(str);
        c1.setBackground(Color.WHITE);
        c1.setBounds(200,100,150,30);
        add(c1);
        
        JLabel status = new JLabel("Cleaning Status");
        status.setFont(new Font("Tahoma", Font.PLAIN, 17));
        status.setBounds(40,140,130,20);
        add(status);
        
        String st[] = {"Cleaned","Not Cleaned"};
        c2 = new JComboBox(st);
        c2.setBackground(Color.WHITE);
        c2.setBounds(200,140,150,30);
        add(c2);
        
        JLabel price = new JLabel("Price");
        price.setFont(new Font("Tahoma", Font.PLAIN, 17));
        price.setBounds(40,180,130,20);
        add(price);
        
        t2 = new JTextField();
        t2.setBounds(200,180,150,30);
        add(t2);
        
        JLabel bed = new JLabel("Bed Type");
        bed.setFont(new Font("Tahoma", Font.PLAIN, 17));
        bed.setBounds(40,220,130,20);
        add(bed);
        
        String strs[] = {"Single Bed","Double Bed"};
        c3 = new JComboBox(strs);
        c3.setBackground(Color.WHITE);
        c3.setBounds(200,220,150,30);
        add(c3);
        
        b1 = new JButton("ADD ROOM");
        b1.setBounds(60,290,100,30);
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.BLACK);
        b1.addActionListener(this);
        add(b1);
        
        b2 = new JButton("CANCEL");
        b2.setBounds(200,290,100,30);
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.BLACK);
        b2.addActionListener(this);
        add(b2);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotelmanagementsystem/icons/twelve.jpg"));
        Image i2 = i1.getImage().getScaledInstance(420, 300,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l2 = new JLabel(i3);
        l2.setBounds(380,20,420,300);
        add(l2);
        
        getContentPane().setBackground(Color.WHITE);
        
        setLayout(null);
        setBounds(230,150,850,390);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            
            String room = t1.getText();
            String available = (String)c1.getSelectedItem();
            String status = (String)c2.getSelectedItem();
            String price = t2.getText();
            String bed = (String)c3.getSelectedItem();
            
            conn c = new conn();
            try{
                String str = "insert into room values('"+room+"','"+available+"','"+status+"','"+price+"','"+bed+"')";
                c.s.executeUpdate(str);
                
            JOptionPane.showMessageDialog(null, "NEW ROOM ADDED");
            this.setVisible(false);
            }catch(Exception e){
                System.out.println(e);
            }
            
            
        }else if(ae.getSource() == b2){
            this.setVisible(false);
        }
    }
    public static void main(String[] args) {
        new AddRooms();
}
}
