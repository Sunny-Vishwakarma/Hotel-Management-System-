package hotelmanagementsystem;

import java.awt.Color;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.*;

public class Room extends JFrame implements ActionListener{
    
    JTable t1;
    JButton b1,b2;
    
    Room(){
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotelmanagementsystem/icons/room.jpg"));
        Image i2 = i1.getImage().getScaledInstance(500, 400,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(490,10,500,400);
        add(l1);
        
        t1 = new JTable();
        t1.setBounds(0,40,480,350);
        add(t1);
        
        b1 = new JButton("Load Data");
        b1.setBounds(50,430,150,30);
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.BLACK);
        b1.addActionListener(this);
        add(b1);
        
        b2 = new JButton("Back");
        b2.setBounds(250,430,150,30);
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.BLACK);
        b2.addActionListener(this);
        add(b2);
        
        JLabel l2 = new JLabel("Room No.");
        l2.setBounds(20,20,70,20);
        add(l2);
        
        JLabel l3 = new JLabel("Availabilty");
        l3.setBounds(110,20,70,20);
        add(l3);
        
        JLabel l4 = new JLabel("Status");
        l4.setBounds(220,20,70,20);
        add(l4);
        
        JLabel l5 = new JLabel("Price");
        l5.setBounds(315,20,70,20);
        add(l5);
        
        JLabel l6 = new JLabel("Bed Type");
        l6.setBounds(400,20,70,20);
        add(l6);
        
        getContentPane().setBackground(Color.WHITE);
        
        setLayout(null);
        setBounds(150,150,1010,520);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            try{
                conn c = new conn();
                String str = "select * from room";
                ResultSet rs = c.s.executeQuery(str);
                
                t1.setModel(DbUtils.resultSetToTableModel(rs));
                
            }catch(Exception e){
                
            }
        }else if(ae.getSource() == b2){
            new Reception().setVisible(true);
            this.setVisible(false);
        }
    }
    public static void main(String[] args) {
        new Room().setVisible(true);
}
}
