package hotelmanagementsystem;

import java.awt.Color;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.*;

public class CustomerInfo extends JFrame implements ActionListener{
    
    JTable t1;
    JButton b1,b2;
    
    CustomerInfo(){
        t1 = new JTable();
        t1.setBounds(0,40,1000,350);
        add(t1);
        
        b1 = new JButton("Load Data");
        b1.setBounds(290,430,150,30);
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.BLACK);
        b1.addActionListener(this);
        add(b1);
        
        b2 = new JButton("Back");
        b2.setBounds(490,430,150,30);
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.BLACK);
        b2.addActionListener(this);
        add(b2);
        
        JLabel l1 = new JLabel("ID");
        l1.setBounds(40,20,70,20);
        add(l1);
        
        JLabel l2 = new JLabel("Number");
        l2.setBounds(170,20,70,20);
        add(l2);
        
        JLabel l4 = new JLabel("Name");
        l4.setBounds(290,20,70,20);
        add(l4);
        
        JLabel l5 = new JLabel("Gender");
        l5.setBounds(420,20,70,20);
        add(l5);
        
        JLabel l6 = new JLabel("Country");
        l6.setBounds(540,20,70,20);
        add(l6);
        
        JLabel l7 = new JLabel("Room");
        l7.setBounds(660,20,70,20);
        add(l7);
        
        JLabel l8 = new JLabel("Status");
        l8.setBounds(780,20,70,20);
        add(l8);
        
        JLabel l9 = new JLabel("Deposit");
        l9.setBounds(900,20,70,20);
        add(l9);
        
        getContentPane().setBackground(Color.WHITE);
        
        setLayout(null);
        setBounds(150,150,1000,520);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            try{
                conn c = new conn();
                String str = "select * from customer";
                ResultSet rs = c.s.executeQuery(str);
                
                t1.setModel(DbUtils.resultSetToTableModel(rs));
                
            }catch(Exception e){
                
            }
        }else if(ae.getSource() == b2){
            new Reception().setVisible(true);
            this.setVisible(false);
        }
    }
    
    public static void main(String[] args) {
        new CustomerInfo().setVisible(true);
}
}
