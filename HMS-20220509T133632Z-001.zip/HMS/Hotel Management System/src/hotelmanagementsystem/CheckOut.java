
package hotelmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.awt.font.*;
import java.awt.color.*;

public class CheckOut extends JFrame implements ActionListener{
    
    JTextField t1;
    Choice c1;
    JButton b1,b2,b3;
    
    CheckOut(){
        JLabel l1 = new JLabel("CHECK OUT");
        l1.setBounds(110,10,260,30);
        l1.setForeground(Color.BLUE);
        l1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(l1);
        
        JLabel l2 = new JLabel("Customer ID");
        l2.setBounds(30,60,70,20);
        add(l2);
        
        c1 = new Choice();
        try{
            conn c = new conn();
            String st = "select * from customer";
            ResultSet rs = c.s.executeQuery(st);            
            while(rs.next()){
                c1.add(rs.getString("number"));
            }
        }catch(Exception e){
            
        }
        c1.setBounds(160,60,150,25);
        add(c1);
        
        JLabel l3 = new JLabel("Room Number");
        l3.setBounds(30,100,100,20);
        add(l3);
        
        t1 = new JTextField();
        t1.setBounds(160,100,150,25);
        add(t1);
        
        b1 = new JButton("Check Out");
        b1.setBounds(90,150,150,30);
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.BLACK);
        b1.addActionListener(this);
        add(b1);
        
        b2 = new JButton("Back");
        b2.setBounds(90,200,150,30);
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.BLACK);
        b2.addActionListener(this);
        add(b2);
        
        getContentPane().setBackground(Color.WHITE);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotelmanagementsystem/icons/tick.png"));
        Image i2 = i1.getImage().getScaledInstance(25,25,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        b3 = new JButton(i3);
        b3.setBounds(315,60,25,25);
        b3.addActionListener(this);
        add(b3);
        
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("hotelmanagementsystem/icons/sixth.jpg"));
        Image i5 = i4.getImage().getScaledInstance(300, 220,Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel l4 = new JLabel(i6);
        l4.setBounds(350,10,300,220);
        add(l4);
        
        setLayout(null);
        setBounds(290,190,690,300);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            String id = c1.getSelectedItem();
            String room = t1.getText();
            String str = "delete from customer where number = '"+id+"'";
            String str2 = "update room set available = 'Available' where room_number = '"+room+"'";
            conn c = new conn();
            try{
                c.s.executeUpdate(str);
                c.s.executeUpdate(str2);
                JOptionPane.showMessageDialog(null, "Checkout Done");
                new Reception().setVisible(true);
                this.setVisible(false);
            }catch(Exception e){
                
            }
        }else if(ae.getSource() == b2){
            new Reception().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource() == b3){
            conn c = new conn();
            String id = c1.getSelectedItem();
            try{
                ResultSet rs = c.s.executeQuery("select * from customer where number = '"+id+"'");
                while(rs.next()){
                    t1.setText(rs.getString("room_number"));
                }
            }catch(Exception e){
                
            }
        }
    }
    public static void main(String[] args) {
        new CheckOut().setVisible(true);
    }
}