
package hotelmanagementsystem;

import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.sql.*;
import java.util.regex.Pattern;

public class AddCustomer extends JFrame implements ActionListener{
    
    JTextField t1,t2,t3,t4,t5;
    JComboBox c1;
    JRadioButton r1,r2;
    Choice c2;
    JButton b1,b2;
    
    AddCustomer(){
        
        JLabel l2 = new JLabel("ID");
        l2.setFont(new Font("Tahoma", Font.PLAIN, 17));
        l2.setBounds(40,50,130,25);
        add(l2);
        
        String str[] = {"Passport","Voter ID","Aadhar Card","Driver License"};
        c1 = new JComboBox(str);
        c1.setBackground(Color.WHITE);
        c1.setBounds(230,50,150,25);
        add(c1);
        
        JLabel l3 = new JLabel("Number");
        l3.setFont(new Font("Tahoma", Font.PLAIN, 17));
        l3.setBounds(40,90,130,25);
        add(l3);
        
        t1 = new JTextField();
        t1.setBounds(230,90,150,25);
        add(t1);
        
        JLabel l4 = new JLabel("Name");
        l4.setFont(new Font("Tahoma", Font.PLAIN, 17));
        l4.setBounds(40,130,130,25);
        add(l4);
        
        t2 = new JTextField();
        t2.setBounds(230,130,150,25);
        add(t2);
        
        JLabel l5 = new JLabel("Gender");
        l5.setFont(new Font("Tahoma", Font.PLAIN, 17));
        l5.setBounds(40,170,130,25);
        add(l5);
        
        r1 = new JRadioButton("Male");
        r1.setFont(new Font("tahoma", Font.PLAIN, 14));
        r1.setBackground(Color.WHITE);
        r1.setBounds(230,170,70,25);
        add(r1);
        
        r2 = new JRadioButton("Female");
        r2.setFont(new Font("tahoma", Font.PLAIN, 14));
        r2.setBackground(Color.WHITE);
        r2.setBounds(300,170,70,25);
        add(r2);
        
        JLabel l6 = new JLabel("Country");
        l6.setFont(new Font("Tahoma", Font.PLAIN, 17));
        l6.setBounds(40,210,130,25);
        add(l6);
        
        t3 = new JTextField();
        t3.setBounds(230,210,150,25);
        add(t3);
        
        JLabel l7 = new JLabel("Allocated Room Number");
        l7.setFont(new Font("Tahoma", Font.PLAIN, 17));
        l7.setBounds(40,250,180,25);
        add(l7);
        
        c2 = new Choice();
        try{
            conn c = new conn();
            String st = "select * from room";
            ResultSet rs = c.s.executeQuery(st);            
            while(rs.next()){
                c2.add(rs.getString("room_number"));
            }
        }catch(Exception e){
            
        }
        c2.setBounds(230,250,150,25);
        add(c2);
        
        JLabel l8 = new JLabel("Checked In");
        l8.setFont(new Font("Tahoma", Font.PLAIN, 17));
        l8.setBounds(40,290,130,25);
        add(l8);
        
        t4 = new JTextField();
        t4.setBounds(230,290,150,25);
        add(t4);
        
        JLabel l9 = new JLabel("Deposit");
        l9.setFont(new Font("Tahoma", Font.PLAIN, 17));
        l9.setBounds(40,330,130,25);
        add(l9);
        
        t5 = new JTextField();
        t5.setBounds(230,330,150,25);
        add(t5);
        
        JLabel l1 = new JLabel("NEW CUSTOMER FORM");
        l1.setBounds(110,0,360,30);
        l1.setForeground(Color.BLUE);
        l1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(l1);
        
        b1 = new JButton("Add New Customer");
        b1.setBounds(50,400,150,30);
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.BLACK);
        b1.addActionListener(this);
        add(b1);
        
        b2 = new JButton("Back");
        b2.setBounds(230,400,150,30);
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.BLACK);
        b2.addActionListener(this);
        add(b2);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotelmanagementsystem/icons/fifth.png"));
        Image i2 = i1.getImage().getScaledInstance(500, 400,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l10 = new JLabel(i3);
        l10.setBounds(390,10,500,400);
        add(l10);
        
        getContentPane().setBackground(Color.WHITE);
        
        setLayout(null);
        setBounds(200,100,900,520);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
    	boolean flag = false;
        if(ae.getSource() == b1){
           String id = (String)c1.getSelectedItem();
           String number = t1.getText();
           if(number.trim().isEmpty())
           {
           	JOptionPane.showMessageDialog(null,"Number is Empty");
           	flag = true;
           }
           if(number.length()!=10) {
        	   JOptionPane.showMessageDialog(null,"Number should be 10 digit");
        		flag = true;
           }
           if(!IsNumberVal(number)) {
        		JOptionPane.showMessageDialog(null,"Invalid Number");
        		flag = true;
           }
           
			/*
			 * if(number.matches("^[0-9]^$") && && ) {
			 * JOptionPane.showMessageDialog(null,""); } else {
			 * JOptionPane.showMessageDialog(null,"Invalid Number"); flag = true; }
			 */
           String name = t2.getText();
           if(name.trim().isEmpty())
           {
           	JOptionPane.showMessageDialog(null,"Name is Empty");
           	flag = true;
           }
          
           if(!isWord(name)) {
        		JOptionPane.showMessageDialog(null,"Invalid Name");
        		flag = true;
           }
			/*
			 * if(name != null && !name.isEmpty() && ) {
			 * JOptionPane.showMessageDialog(null,""); } else {
			 * JOptionPane.showMessageDialog(null,"Invalid Name"); flag = true; }
			 */
           String gender = null;
        if(r1.isSelected()){
            gender = "Male";
        }else if(r2.isSelected()){
            gender = "Female";
        }
           String country = t3.getText();
           String room_number = (String)c2.getSelectedItem();
           String status = t4.getText();
           String deposit = t5.getText();
           if(flag == false) {
        	   AddData(id, number, gender, country, name, room_number, status, deposit);
           }
        
			/*
			 * conn c = new conn(); String str =
			 * "insert into customer values('"+id+"','"+number+"','"+name+"','"+gender+"','"
			 * +country+"','"+room_number+"','"+status+"','"+deposit+"')"; String str2 =
			 * "update room set available = 'occupied' where room_number = '"+room_number+
			 * "'"; try{ c.s.executeUpdate(str); c.s.executeUpdate(str2);
			 * JOptionPane.showMessageDialog(null, "NEW CUSTOMER ADDED"); new
			 * Reception().setVisible(true); this.setVisible(false); }catch(Exception e){
			 * System.out.println(e); }
			 */
        }else if(ae.getSource() == b2){
            new Reception().setVisible(true);
            this.setVisible(false);
        }
    }
    public static boolean IsNumberVal(String number) {
    	try {
    		Integer.parseInt(number);
    		return true;
    	}catch(Exception e){
    		return false;
    	}
    }
    public static boolean isWord(String name) {
    	return Pattern.matches("[a-zA-Z]+", name);
    }
    public static void main(String[] args) {
        new AddCustomer().setVisible(true);
}
    
    public void AddData(String id,String number,String gender,String country,String name,String room_number,String status, String deposit) {
        conn c = new conn();
        String str = "insert into customer values('"+id+"','"+number+"','"+name+"','"+gender+"','"+country+"','"+room_number+"','"+status+"','"+deposit+"')";
        String str2 = "update room set available = 'occupied' where room_number = '"+room_number+"'";
     try{
         c.s.executeUpdate(str);
         c.s.executeUpdate(str2);
         JOptionPane.showMessageDialog(null, "NEW CUSTOMER ADDED");
         new Reception().setVisible(true);
         this.setVisible(false);
     }catch(Exception e){
         System.out.println(e);
     }
    }
}
